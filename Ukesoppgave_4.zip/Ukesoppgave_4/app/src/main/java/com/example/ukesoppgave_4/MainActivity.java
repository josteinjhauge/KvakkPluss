package com.example.ukesoppgave_4;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;

import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import java.util.Locale;

public class MainActivity extends AppCompatActivity implements MyDialog.DialogClickListener{

    public Locale newLang;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d("TAG", "Er i onCreate");
        setContentView(R.layout.activity_main);

        String defaultLand = getDefaultLanguage().toString();
        Log.d("TAG", "språk er: " + defaultLand + " i onCreate");

        if (!defaultLand.equals("nb")) {
            setLang("de");
        }
    }

    public void setLang(String landskode){
        Log.d("TAG","settland med landskode: " + landskode + " kjører nå");

        newLang = Locale.forLanguageTag(landskode);
        Log.d("TAG", "newLang er satt til: " + newLang);

        Resources res = getResources();
        DisplayMetrics dm = res.getDisplayMetrics();
        Configuration cf = res.getConfiguration();
        cf.setLocale(newLang);
        res.updateConfiguration(cf,dm);
    }

    public void tysk(View v) {
        setLang("de");
        recreate();
    }

    public void norsk(View v) {
        setLang("nb");
        recreate();
    }

    public Locale getDefaultLanguage() {
        Resources res = getResources();
        Configuration cf = res.getConfiguration();

        Log.d("TAG", "cf.locale = " + cf.locale);
        return cf.locale;
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d("TAG", "Er i onPause");
        getSharedPreferences("sharedPrefs", MODE_PRIVATE)
            .edit()
            .putString("lang", getDefaultLanguage().toString())
            .apply();

        Log.d("TAG", "I onPause er språk: " + getDefaultLanguage());
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d("TAG", "Er i onResume");
        String language = getSharedPreferences("sharedPrefs", MODE_PRIVATE)
                .getString("lang","");
        Log.d("TAG", "Språk fra SP er: " + language);
        setLang(language);

        Log.d("TAG", "I onResume er språk satt til: " + getDefaultLanguage());
    }

    @Override
    public void onAvsluttClick() {
        finish();
    }

    @Override
    public void onAvbrytClick() {
        return;
    }

    public void visDialog(View v) {
        DialogFragment dialog = new MyDialog();
        dialog.show(getSupportFragmentManager(), "Avslutt");
    }

    public void visPreferences(View v) {
    }



}